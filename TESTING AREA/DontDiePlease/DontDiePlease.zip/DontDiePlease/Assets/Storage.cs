﻿using UnityEngine;
using System.Collections;

public class Storage {

    //Managers
    public static MyCoolManager myCoolManager;

    //GameObjects
    public static GameObject myCoolGameObject;
}
